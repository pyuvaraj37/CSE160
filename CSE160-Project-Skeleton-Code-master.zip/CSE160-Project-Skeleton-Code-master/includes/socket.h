#ifndef __SOCKET_H__
#define __SOCKET_H__

enum{
    MAX_NUM_OF_SOCKETS = 10,
    ROOT_SOCKET_ADDR = 255,
    ROOT_SOCKET_PORT = 255,
    SOCKET_BUFFER_SIZE = 128,
};

enum retransmit{
    NO,
    YES,
};

enum socket_state{
    CLOSED,
    LISTEN,
    ESTABLISHED,
    SYN_SENT,
    SYN_RCVD,
    FIN_WAIT_1,
    FIN_WAIT_2,
    TIME_WAIT,
    LAST_ACK,
    CLOSE_WAIT,
};

enum flag_state{
    OPN, 
    SYN,
    SYN_ACK,
    ACK,
    DATA,
    FIN,
};


typedef nx_uint8_t nx_socket_port_t;
typedef uint8_t socket_port_t;

// socket_addr_t is a simplified version of an IP connection.
typedef nx_struct socket_addr_t{
    nx_socket_port_t srcPort;
    nx_socket_port_t destPort;
    nx_uint16_t srcAddr;
    nx_uint16_t destAddr;
}socket_addr_t;


// File descripter id. Each id is associated with a socket_store_t
typedef uint8_t socket_t;

// State of a socket. 
typedef struct socket_store_t{

    socket_t id;
    uint8_t* username;
    enum retransmit redo;
    enum socket_state state;
    socket_addr_t address;
    
    bool writerEnable; 
    bool readerEnable; 

    // This is the sender portion.
    uint8_t sendBuff[SOCKET_BUFFER_SIZE];
    uint8_t lastWritten;
    uint8_t lastAck;
    uint8_t lastSent;

    // This is the receiver portion
    uint8_t rcvdBuff[SOCKET_BUFFER_SIZE];
    uint8_t lastRead;
    uint8_t lastRcvd;
    uint8_t nextExpected;

    uint8_t transferSize;
    uint8_t numReceived; 
    uint8_t numSent; 

    uint16_t RTT;
    uint8_t effectiveWindow;
}socket_store_t;

typedef struct tcp{
    uint8_t srcPort;
    uint8_t destPort;
    uint16_t seq;
    uint16_t ack;
    enum flag_state flag;
    uint8_t transferSize; 
    uint8_t window;
    uint8_t data[SOCKET_BUFFER_SIZE];
}tcp;


#endif
