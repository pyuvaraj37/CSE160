
#ifndef LS_H
#define LS_H


typedef nx_struct link{
    nx_uint16_t source;
    nx_uint16_t hop;
    nx_uint16_t neighbor;      
}link;

#endif
